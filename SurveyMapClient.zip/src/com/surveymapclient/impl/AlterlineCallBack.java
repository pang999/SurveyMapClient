package com.surveymapclient.impl;

import com.surveymapclient.entity.CouplePointLineBean;

public interface AlterlineCallBack {

	void onAlterlineCallBack(CouplePointLineBean line);
}
