package com.surveymapclient.impl;

public interface VibratorCallBack {

	void onVibratorCallBack();
}
