package com.surveymapclient.impl;


public interface MyPlayerCallback {

	public void onPrepared();

	public void onCompletion();

}
