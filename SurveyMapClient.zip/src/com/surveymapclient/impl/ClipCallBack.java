package com.surveymapclient.impl;

import android.graphics.Canvas;

public interface ClipCallBack {

	void OnClipCallBack(Canvas canvas);
}
