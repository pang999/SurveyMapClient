package com.surveymapclient.impl;

import com.surveymapclient.entity.CouplePointLineBean;

public interface DialogCallBack {

	void onDialogCallBack(CouplePointLineBean couplePoint,int i);
}
