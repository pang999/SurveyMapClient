package com.surveymapclient.entity;


public class AngleIndexBean {

	private double area;
	private int index;
	public double getArea() {
		return area;
	}
	public void setArea(double area) {
		this.area = area;
	}
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}

	
}
